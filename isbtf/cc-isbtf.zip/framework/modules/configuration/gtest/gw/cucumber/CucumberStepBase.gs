package gw.cucumber

uses com.google.inject.Inject
uses gw.plugin.policy.impl.PolicySearchPluginDemoImpl
uses gw.plugin.policy.search.IPolicySearchAdapter
uses gw.sampledata.SampleDataGroup
uses gw.testharness.v3.PLAssertions
uses org.fest.assertions.*
uses org.slf4j.Logger
uses pcftest.TabBar

@ReadOnly
class CucumberStepBase {

  @Inject
  protected var _proxy : CCCucumberSmokeTestProxy

  protected var _defaultUser : String = "aapplegate"

  property get DefaultUser() : String {
    return _defaultUser
  }

  function loginDefaultUser() : TabBar {
    return login(DefaultUser, "gw")
  }

  function loginAsUser(username : String) : TabBar {
    return login(username, "gw")
  }

  function login(username : String, password : String) : TabBar {
    _proxy.TabBar = (_proxy.goToEntryPoint("Login") as pcftest.Login).loginAndReturnTabBar(username, password)
    return _proxy.TabBar
  }

  function registerPolicySearchPlugin() {
    _proxy.registerPlugin(IPolicySearchAdapter, new PolicySearchPluginDemoImpl())
  }

  property get Logger() : Logger {
    return _proxy.Logger
  }

  protected function assertThat(actual : Object) : ObjectAssert {
    return PLAssertions.assertThat(actual)
  }

  protected function assertThat(actual : String) : StringAssert {
    return PLAssertions.assertThat(actual)
  }

  protected function assertThat(actual : Object[]) : ObjectArrayAssert {
    return PLAssertions.assertThat(actual)
  }

  protected function assertThat(actual : Collection<Object>) : CollectionAssert {
    return PLAssertions.assertThat(actual)
  }

  protected function assertThat(actual : Boolean) : BooleanAssert {
    return PLAssertions.assertThat(actual)
  }

  protected function assertThat(actual : int) : IntAssert {
    return PLAssertions.assertThat(actual)
  }

  protected function assertThat(actual : long) : LongAssert {
    return PLAssertions.assertThat(actual)
  }

  protected function loadTestSampleData() {
    try {
      gw.transaction.Transaction.runWithNewBundle(\bundle -> {
        SampleDataGroup.Test.load()
      }, "su")
    } catch (e) {
      Logger.warn(e.Message)
      if (Logger.DebugEnabled) Logger.debug(e.Message, e)
    }
  }
}
