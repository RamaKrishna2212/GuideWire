package gw.enhancement.validationmessagehandler

uses gw.enhancement.util.StructuralType
uses gw.smoketest.platform.web.PCFLocation
uses pcftest.NewActivity

class ActivityValidationMessageHandler extends ValidationMessageHandler<PCFLocation, ActivityValidationMessageHandler> {
  construct(start : PCFLocation, uiValidationMessageReader : block() : List<String> = null) {
    super(start, uiValidationMessageReader)
    withCloseValidationMessagesWorksheet()
  }

  /**
   * Presses the Complete button in the PCF, then verifies that all and only the expected validation messages appeared.
   * It does NOT verify the state of the Activity.
   **/
  function completeSuccessfully() : PCFLocation {
    return navigate(\-> (Start as StructuralType.DefinesComplete).complete())
  }

  /**
   * Presses the Complete button in the PCF, then verifies that all and only the expected validation messages appeared.
   * It does NOT verify the state of the Activity.
   **/
  function completeUnsuccessfully() : PCFLocation {
    return navigate(\-> (Start as StructuralType.DefinesComplete).complete())
  }

  /**
   * Presses the CompleteAndCreateNew button in the PCF, then verifies that all and only the expected validation messages appeared.
   * It does NOT verify the state of the Activity.
   **/
  function completeAndCreateNewSuccessfully() : NewActivity {
    return navigate(\-> (Start as StructuralType.DefinesCompleteAndCreateNew).completeAndCreateNew())
  }

  /**
   * Presses the completeAndCreateNew button in the PCF, then verifies that all and only the expected validation messages appeared.
   * It does NOT verify the state of the Activity.
   **/
  function completeAndCreateNewUnsuccessfully() : PCFLocation {
    return navigate(\-> (Start as StructuralType.DefinesCompleteAndCreateNew).completeAndCreateNew())
  }

  /**
   * Presses the Skip button in the PCF, then verifies that all and only the expected validation messages appeared.
   * It does NOT verify the state of the Activity.
   **/
  function skipSuccessfully() : PCFLocation {
    return navigate(\-> (Start as StructuralType.DefinesSkip).skip())
  }

  /**
   * Presses the Skip button in the PCF, then verifies that all and only the expected validation messages appeared.
   * It does NOT verify the state of the Activity.
   **/
  function skipUnsuccessfully() : PCFLocation {
    return navigate(\-> (Start as StructuralType.DefinesSkip).skip())
  }

  /**
   * Presses the Update button in the PCF, then verifies that all and only the expected validation messages appeared.
   * It does NOT verify the state of the Activity.
   **/
  function updateSuccessfully() : PCFLocation {
    return navigate(\-> (Start as StructuralType.DefinesUpdate).update())
  }

  /**
   * Presses the Update button in the PCF, then verifies that all and only the expected validation messages appeared.
   * It does NOT verify the state of the Activity.
   **/
  function updateUnsuccessfully() : PCFLocation {
    return navigate(\-> (Start as StructuralType.DefinesUpdate).update())
  }

  function cancelSuccessfully() : PCFLocation {
    return navigate(\-> (Start as StructuralType.DefinesCancel).cancel())
  }

  function cancelUnsuccessfully() : PCFLocation {
    return navigate(\-> (Start as StructuralType.DefinesCancel).cancel())
  }
}