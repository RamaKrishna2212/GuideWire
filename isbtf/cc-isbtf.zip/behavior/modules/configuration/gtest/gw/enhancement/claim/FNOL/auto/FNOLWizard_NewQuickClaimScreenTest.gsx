package gw.enhancement.claim.FNOL.auto

uses gw.api.locale.DisplayKey
uses gw.api.util.DateUtil
uses org.junit.Assert
uses pcf.api.Wizard
uses pcftest.CCAddressInputSet
uses pcftest.FNOLWizard_NewQuickClaimScreen

enhancement FNOLWizard_NewQuickClaimScreenTest : FNOLWizard_NewQuickClaimScreen {

  property get Wizard() : pcftest.FNOLWizard {
    return this.SmokeTest.CurrentPage as pcftest.FNOLWizard
  }

  function assertOnStep() {
    Assert.assertTrue("Should be on auto first and final wizard step", Wizard.QuickClaimAuto.Current)
  }

  function setRequiredFields() {
    var qca = this.QuickClaimDV_QuickClaimAuto
    if (isFieldBlank(qca.ReportedBy_Name.Value))           qca.ReportedBy_Name.selectFirstValidOption()
    if (isFieldBlank(qca.Claim_ReportedByType.Value))      qca.Claim_ReportedByType.selectFirstValidOption()
    if (isFieldBlank(qca.Claim_LOBCode.Value))             qca.Claim_LOBCode.selectFirstValidOption()
    if (isFieldBlank(qca.Claim_LossCause.Value))           qca.Claim_LossCause.selectFirstValidOption()
    if (isFieldBlank(qca.Notification_ReportedDate.Value)) qca.Notification_ReportedDate.setDateValue(DateUtil.currentDate())

    if (isAddressUnset(qca.CCAddressInputSet)) {
      qca.CCAddressInputSet.setAddress("Address line 1", "San Jose", State.TC_CA, "12345")
    }
  }

  private function isFieldBlank(fieldValue : String) : boolean {
    return not fieldValue.HasContent
  }

  private function isAddressUnset(address : CCAddressInputSet) : boolean {
    if (address.Address_Picker.Value == DisplayKey.get("Web.Financials.ReserveLineInputSet.ReserveLine.New")) {
      return not (address.Address_City.Value.HasContent and (address.Address_State.Value != "<none>"))
    }
    else return false
  }

}