package gw.enhancement.claim.FNOL

uses junit.framework.Assert

enhancement FNOLWizard_ServicesScreen_AutoTestEnhancement : pcftest.FNOLWizard_ServicesScreen_Auto {

  function createAppraisalService(contactName: String) {
    var appraisalService = this.get_Entries().get(0).VehicleIncidentPanelSet.AppraisalServiceDV
        .AppraisalServiceInputSet.AppraisalServiceInputSet.AppraisalServiceInputGroup
    appraisalService.get_checkbox().click()
    var newContactPopup = appraisalService.Assessor_Picker.ClaimNewVendorOnlyPickerMenuItemSet.NewContactPickerMenuItemSet_CompanyVendor.click()
    var contactBasicsDV = newContactPopup.ContactDetailScreen.ContactBasicsDV_CompanyVendor
    contactBasicsDV.OrganizationName.GlobalContactNameInputSet_default.Name.setValue(contactName)
    contactBasicsDV.PrimaryAddressInputSet.CCAddressInputSet.globalAddressContainer.globalAddress.GlobalAddressInputSet_default.AddressLine1.setValue("test")
    newContactPopup.ContactDetailScreen.ContactBasicsDV_tb.ContactDetailToolbarButtonSet.CustomUpdateButton.click()

    appraisalService.OtherServiceRequestInfo.NewServiceRequestInstructionInputSet_default.ServiceAddressPicker.selectFirstValidOption()
  }
}
