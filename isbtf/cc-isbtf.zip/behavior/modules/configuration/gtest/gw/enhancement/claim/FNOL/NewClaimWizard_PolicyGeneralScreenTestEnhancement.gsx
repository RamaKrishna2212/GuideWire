package gw.enhancement.claim.FNOL

uses junit.framework.Assert

enhancement NewClaimWizard_PolicyGeneralScreenTestEnhancement : pcftest.NewClaimWizard_PolicyGeneralScreen {

  property get Wizard() : pcftest.FNOLWizard {
    return this.SmokeTest.CurrentPage as pcftest.FNOLWizard
  }

  function assertOnStep() {
    Assert.assertTrue("Should be on policy general wizard step", Wizard.IndependentWizardStepSet.PolicyWizardStepGroup.PolicyGeneral.Current)
  }
}