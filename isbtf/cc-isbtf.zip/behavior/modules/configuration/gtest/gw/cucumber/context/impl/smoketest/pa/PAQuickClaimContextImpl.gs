package gw.cucumber.context.impl.smoketest.pa

uses gw.api.locale.DisplayKey
uses gw.cucumber.context.api.pa.PAQuickClaimContext
uses gw.cucumber.transformer.TypelistTransformer
uses pcftest.NewClaimSaved

class PAQuickClaimContextImpl extends PAClaimContextImpl implements PAQuickClaimContext {

  override function startFilingQuickClaimAuto() {
    var policy = _policyDataSetWrapper.get()
    var wizard = _proxy.TabBar.goToNewClaim()
    if (policy != null) {
      wizard.SelectPolicy.findPolicy(policy.PolicyNumber, Date.Today)
      wizard.SelectPolicy.FNOLWizardFindPolicyPanelSet_Search.ClaimMode.clickByLabelSubstr(DisplayKey.get("Wizard.NewClaimWizard.QuickClaimAuto.Label"))
    }
  }

  override function finishFilingClaim() {
    var wizard = Wizard
    wizard.goToQuickClaimAutoPage()

    wizard.QuickClaimAuto.FNOLWizard_NewQuickClaimScreen.setRequiredFields()

    var newClaimSaved = wizard.finish()
    if (wizard.ignoreDuplicateClaimsWarningIfPresent()) {
      newClaimSaved = wizard.finish()
    }
    captureNewlyCreatedClaim((newClaimSaved as NewClaimSaved).ClaimEntity)
  }

  override function reportedByInsured() {
    var wizard = Wizard
    wizard.goToQuickClaimAutoPage()
    var dv = wizard.QuickClaimAuto.FNOLWizard_NewQuickClaimScreen.QuickClaimDV_QuickClaimAuto
    dv.ReportedBy_Name.getOptionByLabel(Wizard.InsuredName).click()
    dv.Claim_ReportedByType.getOptionByValue(PersonRelationType.TC_SELF as String).click()
  }

  override function setLossCause(lossCauseText : String) {
    var lossCause = new TypelistTransformer<LossCause>().transform(lossCauseText)
    var wizard = Wizard
    wizard.goToQuickClaimAutoPage()
    var dv = wizard.QuickClaimAuto.FNOLWizard_NewQuickClaimScreen.QuickClaimDV_QuickClaimAuto
    dv.Claim_LossCause.TypeKeyValue = lossCause
  }

  override function setLossLocationInState(stateText : String) {
    var state = new TypelistTransformer<State>().transform(stateText)
    var wizard = Wizard
    wizard.goToQuickClaimAutoPage()
    var dv = wizard.QuickClaimAuto.FNOLWizard_NewQuickClaimScreen.QuickClaimDV_QuickClaimAuto
    dv.CCAddressInputSet.setAddress("123 St", "San Mateo", state, "94400")
  }

}