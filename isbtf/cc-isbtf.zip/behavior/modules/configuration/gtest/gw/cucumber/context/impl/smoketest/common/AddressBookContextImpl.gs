package gw.cucumber.context.impl.smoketest.common

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.api.contact.ContactSystemPluginAdapter
uses gw.cucumber.CucumberStepBase
uses gw.cucumber.context.api.common.AddressBookContext
uses gw.cucumber.testdata.DataWrapper
uses gw.cucumber.transformer.ContactSearchCriteriaTransformer
uses gw.cucumber.transformer.TypelistTransformer
uses gw.plugin.contact.search.ContactSearchFilter

@SuppressWarnings("unused")
class AddressBookContextImpl extends CucumberStepBase implements AddressBookContext {

  @Inject
  var _contactWrapper : DataWrapper<entity.Contact>

  override function verifyContactIsInAddressBook(contactSubTypeName : String, table : DataTable) {
    var contactSubType = new TypelistTransformer<typekey.Contact>().transform(contactSubTypeName)
    var _contactSystemPlugin = ContactSystemPluginAdapter.getAdapter()
    var searchCriteria = new ContactSearchCriteriaTransformer().transform(contactSubType, table, CurrentUser)
    var result = _contactSystemPlugin.searchContacts(searchCriteria, new ContactSearchFilter())

    assertThat(result.NumberOfResults).isEqualTo(1)
    _contactWrapper.set(result.Contacts.single())
  }

}
