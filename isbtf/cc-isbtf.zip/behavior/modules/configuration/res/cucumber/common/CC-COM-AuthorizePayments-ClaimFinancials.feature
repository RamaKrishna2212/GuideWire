@common @CC-COM-AuthorizePayments-ClaimFinancials
Feature: Transaction approvals

  As an adjuster,
  I want to be able to create and edit reserves and checks,
  So that claim financials can be recorded and maintained.

  Background:
    Given I am a user with the "Adjuster" role
    And I have the following authority limits
      | Limit Type             | Amount |
      | Claim payments to date | 5000   |
    And I have the "Approve any approval activity" permission

  @23290.7-GW
  Scenario Outline: Creating a check requires appropriate authority
    Given a Personal Auto claim
    And the claim has a bodily injury exposure
    And the exposure has available reserves for
      | Cost Type  | Cost Category  | Amount   |
      | Claim Cost | Auto body      | 11000    |
    When I create a check for "<Amount>" on the exposure
      | Payment Type | Eroding? |
      | Partial      | Yes      |
    Then the check's approval status should be "<Check Approval Status>"
    And the payment's approval status should be "<Payment Approval Status>"

  Examples:
    | Amount | Check Approval Status | Payment Approval Status |
    | 1000   | Awaiting submission   | Awaiting submission     |
    | 10000  | Pending approval      | Pending approval        |

  @23290.7-GW
  Scenario Outline: Actioning a check
    Given a Personal Auto claim
    And the claim has a bodily injury exposure
    And the exposure has available reserves for
      | Cost Type  | Cost Category  | Amount   |
      | Claim Cost | Auto body      | 11000    |
    And a check for "<Amount>" on the exposure requires approval
    When I "<Action>" the payment
    Then the check's approval status should be "<Check Approval Status>"
    And the payment's approval status should be "<Payment Approval Status>"

  Examples:
    | Amount | Action  | Check Approval Status | Payment Approval Status |
    | 1000   | Approve | Awaiting submission   | Awaiting submission     |
    | 1000   | Reject  | Rejected              | Rejected                |
    | 10000  | Approve | Pending approval      | Pending approval        |