@common @CC-COM-CaptureResponses-ClaimMaintenance
Feature: Claim Associations

  As an Adjuster,
  I want to associate claims
  So that I can ensure data on the claim represents the loss

  Background:
    Given I am a user with the "Adjuster" role

  @23130-GW
  Scenario: Create a new association between 2 claims
    Given a Personal Auto claim
    And another Personal Auto claim
    When I associate these claims with the title "Prior claim on the vehicle"
    Then an association with the title "Prior claim on the vehicle" should exist between both claims

  @23130-GW
  Scenario: Find an association between 2 claims
    Given a Personal Auto claim
    And another Personal Auto claim
    And these claims are associated with the title "Prior claim on the vehicle"
    Then an association with the title "Prior claim on the vehicle" should exist between both claims

  @23130-GW
  Scenario: Update an association between 2 claims
    Given a Personal Auto claim
    And another Personal Auto claim
    When I associate these claims with the title "Prior claim on the vehicle"
    And I change the "Prior claim on the vehicle" association type to "Parent/child"
    Then an association with the title "Prior claim on the vehicle" and type "Parent/child" should exist between both claims

  @23130-GW
  Scenario: Delete an association between 2 claims
    Given a Personal Auto claim
    And another Personal Auto claim
    When I associate these claims with the title "Prior claim on the vehicle"
    And I delete the "Prior claim on the vehicle" association
    Then an association with the title "Prior claim on the vehicle" should not exist between both claims
