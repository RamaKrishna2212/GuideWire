@common @CC-COM-SysFuncClaims-ClaimFinancials
Feature: Define financial summary presentation

  As an adjuster,
  I want to be able to view summary financials for my claim file
  So that I can verify the expenses on a claim

  Background:
    Given I am a user with the "Adjuster" role
    And I have the "Adjuster" authority limit profile

  @23330-GW
  Scenario Outline: Financial Summary Screens
    Given a Personal Auto claim
    And the claim has a "<Exposure>" exposure
    And the exposure has "<Reserve Amount>" available reserves for "<Cost Type>" and "<Cost Category>"
    And the exposure has a check with a "<Check Amount>" "<Payment Type>" payment on the reserve line
    Then a transaction should be visible on the "<View>" Financials Summary screen
      | Exposure   | Reserve Amount   | Cost Type   | Cost Category   | Check Amount   | Payment Type   |
      | <Exposure> | <Reserve Amount> | <Cost Type> | <Cost Category> | <Check Amount> | <Payment Type> |

    Examples:
      | View            | Exposure             | Reserve Amount | Cost Type             | Cost Category             | Check Amount | Payment Type |
      | Exposure        | Collision            | 1000           | Claim Cost            | Unspecified Cost Category | 500          | Partial      |
      | Claim Cost only | Medical Payments     | 800            | Claim Cost            | Medical                   | 400          | Partial      |
      | Coverage        | Collision            | 900            | Claim Cost            | Auto body                 | 700          | Final        |
      | Exposure only   | Collision            | 850            | Unspecified Cost Type | Labor                     | 300          | Partial      |

  @23330-GW @multicurrency
  Scenario: Financial Summary Screen - Multiple currencies
    Given a Personal Auto claim
    And the claim has a "Collision" exposure
    And the exposure has "1000 USD" available reserves for "Unspecified Cost Type" and "Unspecified Cost Category"
    And the exposure has "900 EUR" available reserves for "Claim Cost" and "Auto parts"
    And the exposure has a check with a "200 USD" "Partial" payment on the reserve line
    When I create a check with a "300 EUR" "Partial" payment on the reserve line
    Then multi-currency transactions should be listed on the claim
      | Exposure  | Reserve Amount | Cost Type             | Cost Category             | Check Amount | Payment Type |
      | Collision | 1000 USD       | Unspecified Cost Type | Unspecified Cost Category | 200 USD      | Partial      |
      | Collision | 900 EUR        | Claim Cost            | Auto parts                | 300 EUR      | Partial      |
