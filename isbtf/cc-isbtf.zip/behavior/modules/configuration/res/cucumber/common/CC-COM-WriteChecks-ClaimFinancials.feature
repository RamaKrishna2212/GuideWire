@common @CC-COM-WriteChecks-ClaimFinancials
Feature: Create reserves and checks

  As an adjuster,
  I want to be able to create and edit reserves and checks, so that I can manage the payments on the claim

  Background:
    Given I am a user with the "Adjuster" role
    And I have the "Adjuster" authority limit profile

  @23290.2-GW
  Scenario: Create a manual check
    Given a Personal Auto claim
    And the claim has a "Collision" exposure
    And I set the available reserves for "Claim Cost"/"Auto body" to "300 USD"
    When I create a manual check with a "200 USD" "Partial" payment on the reserve line
    Then a "200 USD" "Partial" payment should exist on the reserve line
    And the exposure should have the following remaining reserves:
      | Cost Type  | Cost Category | Amount  |
      | Claim Cost | Auto body     | 100 USD |

  @23290.2-GW
  Scenario: Create a manual check exceeding the available reserve
    Given a Personal Auto claim
    And the claim has a "Collision" exposure
    And I set the available reserves for "Claim Cost"/"Auto body" to "300 USD"
    When I create a manual check with a "400 USD" "Partial" payment on the reserve line
    Then a "400 USD" "Partial" payment should exist on the reserve line
    And the exposure should have the following remaining reserves:
      | Cost Type  | Cost Category | Amount |
      | Claim Cost | Auto body     | 0 USD  |

  @23290.3-GW
  Scenario: Create a payment quick check
    Given a Personal Auto claim
    And the claim has a "Collision" exposure
    And I set the available reserves for "Claim Cost"/"Auto body" to "300 USD"
    When I create a quick check with the following details:
      | Cost Type     | Payee                 | Amount  | Currency | Payment Type | Eroding |
      | Auto body USD | Quick Check Recipient | 300 USD | USD      | Partial      | Yes     |
    Then a "300 USD" "Partial" payment should exist on the reserve line
    And the exposure should have the following remaining reserves:
      | Cost Type  | Cost Category | Amount |
      | Claim Cost | Auto body     | 0 USD  |
