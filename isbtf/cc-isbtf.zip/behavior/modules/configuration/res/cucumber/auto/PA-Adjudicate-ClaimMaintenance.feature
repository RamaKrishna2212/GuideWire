@personal_auto @PA-Adjudicate-ClaimMaintenance
Feature: Exposure

  As an adjuster,
  I want to create and update incidents on existing claims. So that I can track the losses that have occurred in this claim.

  Background:
    Given I am a user with the "Adjuster" role

  @23460.1-GW
  Scenario: Creating a vehicle incident on a claim
    Given a Personal Auto claim
# George Clooney is created as a Reporter against new PA claims. Use George Clooney
# during Vehicle Incident as the driver so the on change helper when setting the vehicle driver does not
# reset any required fields on the vehicle incident.
    And the policy on the claim has the following covered parties:
      | First  | Last    |
      | George | Clooney |
    And the policy on the claim has the following covered vehicles:
      | Year | Make   | Model   |
      | 2001 | Acura  | RSX     |
    When I add a vehicle incident
      | Vehicle        | License Plate | Driver Name    | Loss Occurred? | Damage Description              |
      | 2001 Acura RSX | 64RJK12       | George Clooney | At premises    | Side panel scratched and dented |
    Then a vehicle incident should be created on the claim
      | Vehicle        | License Plate | Driver Name    | Loss Occurred? | Damage Description              |
      | 2001 Acura RSX | 64RJK12       | George Clooney | At premises    | Side panel scratched and dented |

  @23460.1-GW
  Scenario: Editing involved vehicle and driver for a vehicle incident
    Given a Personal Auto claim
    And the policy on the claim has the following covered vehicles
      | Year | Make   | Model   |
      | 2001 | Acura  | RSX     |
      | 1997 | Toyota | Corolla |
    And the policy on the claim has the following covered parties
      | First  | Last    |
      | Brooke | Wynn    |
      | George | Clooney |
    And a collision exposure for vehicle "2001 Acura RSX"
    When I change involved vehicle for the incident to "1997 Toyota Corolla"
# George Clooney is created as a Reporter against new PA claims. Use George Clooney
# during Vehicle Incident as the driver so the on change helper when setting the vehicle driver does not
# reset any required fields on the vehicle incident.
    And I change driver of the involved vehicle to "George Clooney"
    Then the involved vehicle on the incident should be "1997 Toyota Corolla"
    And the driver of the involved vehicle should be "George Clooney"

  @23460.2-GW
  Scenario: Creating property incident on a claim
    Given a Personal Auto claim
    When I add a new property to the claim
      | Property Description | Damage Description  | Loss Estimate | Address 1     | City          | State      |
      | 2 bed apartment      | Flooding to bedroom | 800           | 1 Main Street | San Francisco | California |
    Then the property incident should be listed on the claim
      | Property Description | Damage Description  | Loss Estimate | Address 1     | City          | State      |
      | 2 bed apartment      | Flooding to bedroom | 800           | 1 Main Street | San Francisco | California |

  @23460.3-GW
  Scenario: Creating injury incident on a claim
    Given a Personal Auto claim
    And the policy on the claim has the following covered parties:
      | First  | Last    |
      | Brooke | Wynn    |
    When I add a new injury incident
      | Injured Person | Loss Party     | Severity | General Injury Type | Detailed Injury Type |
      | Brooke Wynn    | Insured's loss | Moderate | Specific injury     | Concussion           |
    Then the injury incident should be listed on the claim
      | Injured Person | Loss Party     | Severity | General Injury Type | Detailed Injury Type |
      | Brooke Wynn    | Insured's loss | Moderate | Specific injury     | Concussion           |
