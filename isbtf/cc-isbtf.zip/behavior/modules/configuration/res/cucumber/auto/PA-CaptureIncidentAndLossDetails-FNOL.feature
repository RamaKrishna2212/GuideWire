@personal_auto @PA-CaptureIncidentAndLossDetails-FNOL
Feature: Capture incident and loss details

  As a customer service representative,
  I want to file claims against verified policies, and capture incident and loss details
  So that I can progress the claim

  Background:
    Given I am a user with the "Customer Service Representative" role
    And I have the "Adjuster" authority limit profile

  @23370-GW
  Scenario: Filing a new Personal Auto Claim using Quick Claim Wizard
    Given a Personal Auto policy
    When I start filing a claim in Quick Claim Auto Wizard
    And I set the Loss Date to "today"
    And the claim was reported by the Insured
    And I set claim loss cause to "Collision with motor vehicle"
    And I set loss location to an address in state "California"
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And the claim should have a loss location in the state of "California"
    And the claim loss cause should be "Collision with motor vehicle"

  @23410.1-GW
  Scenario: Filing a new Personal Auto Claim with vehicle damage information
    Given a Personal Auto policy
    When I start filing a claim
    And I add a third party vehicle
      | Vehicle Type | Year | Make | Model | Damage Description | Possible Total Loss? | Operable? | Airbags Deployed? | Equipment Failure? |
      | Owned        | 2001 | Ford | Focus | Left panel dented  | No                   | Yes       | Yes               | Yes                |
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And a damaged vehicle should exist on the claim
      | Vehicle Type | Year | Make | Model | Damage Description | Possible Total Loss? | Operable? | Airbags Deployed? | Equipment Failure? |
      | Owned        | 2001 | Ford | Focus | Left panel dented  | No                   | Yes       | Yes               | Yes                |

  @23410.3-GW-2
  Scenario: Filing a new Personal Auto Claim with property damage information
    Given a Personal Auto policy
    When I start filing a claim
    And I add a property damage liability
      | Property Description | Damage Description | Loss Estimate | Address 1     | City          | State      |
      | 2 bed apartment      | Flooded bathroom   | 500           | 1 Main Street | San Francisco | California |
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And a property damage liability should exist on the claim
      | Property Description | Damage Description | Loss Estimate | Address 1     | City          | State      |
      | 2 bed apartment      | Flooded bathroom   | 500           | 1 Main Street | San Francisco | California |

  @23410-GW
  Scenario: Filing a new Personal Auto Claim with reports by officials at the scene
    Given a Personal Auto policy
    When I start filing a claim
    And I select an involved vehicle from covered vehicles
    And I add a witness report
      | Name        | Statement Obtained | Where was the witness? | Perspective |
      | Ray Newton  | Yes                | Pedestrian             | Side        |
    And I add a police report
      | Metro Report Type | City of Investigating Agency | State of Investigating Agency | Insured Vehicle     |
      | Auto Accident     | San Francisco                | California                    | 1996 Toyota Corolla |
    And I add a report from an "Ambulance" official
      | Name              | Report # |
      | George Washington | 1337     |
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And the claim should have a witness report
      | Name        | Statement Obtained | Where was the witness? | Perspective |
      | Ray Newton  | Yes                | Pedestrian             | Side        |
    And the claim should have a police report
      | Metro Report Type | City of Investigating Agency | State of Investigating Agency | Insured Vehicle     |
      | Auto Accident     | San Francisco                | California                    | 1996 Toyota Corolla |
    And the claim should have a report from a "Ambulance" official
      | Name              | Report # |
      | George Washington | 1337     |

  @23410-GW
  Scenario: Filing a new Personal Auto Claim with specific categorization including fault rating
    Given a Personal Auto policy
    When I start filing a claim
    And I set the fault rating to "Other party at fault"
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And the fault rating should be "Other party at fault"