@personal_auto
Feature: Activity

  As an adjuster,
  I want to add new activities to existing claims and also perform actions on open activities.

  Background:
    Given I am a user with the "Adjuster" role

  Scenario: A New Activity is created on an existing claim
    Given a Personal Auto claim
    And the claim has a "collision" exposure
    And I choose the insured to be the claimant for the vehicle exposure
    And I am the claim owner
    When I create the following "Get police report" Activity:
      | Related To          | Claim                |
      | Assign To           | Claim/Exposure Owner |
    Then the following activities should be on the claim:
      | Subject                             | Related To | Status | Assigned To |
      | Get police report                   | Claim      | open   | Claim Owner |