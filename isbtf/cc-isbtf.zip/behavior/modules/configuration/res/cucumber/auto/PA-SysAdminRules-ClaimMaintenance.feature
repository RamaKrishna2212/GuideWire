@personal_auto @PA-SysAdminRules-ClaimMaintenance
Feature: Business Rules - Claim Maintenance

  As a customer service representative,
  I want to be able to validate exposure rules.
  While as Business Rules Admin,
  I want to be able to create and edit exposure rules.

  @23480-2-GW
  Scenario: Validate a business rule doesn't run
    Given I am a user with the "Customer Service Representative" role
    And I have the "Adjuster" authority limit profile
    And an exposure rule named "TestRule2" is "Staged"
      | Enabled | Policy Type   | Incident Type   | Action Type     | Coverage Type | Coverage Subtype |
      | Yes     | Personal Auto | VehicleIncident | Create Exposure | Collision     | Collision        |
    And a Personal Auto policy
    When I start filing a claim
    And I finish filing the claim
    Then an exposure should not be created on the claim
      | Coverage Type | Coverage Subtype |
      | Collision     | Collision        |

  @23480-2-GW
  Scenario: Validate a business rule runs
    Given I am a user with the "Customer Service Representative" role
    And I have the "Adjuster" authority limit profile
    And an exposure rule named "TestRule1" is "Staged"
      | Enabled | Policy Type   | Incident Type   | Action Type     | Coverage Type | Coverage Subtype |
      | Yes     | Personal Auto | VehicleIncident | Create Exposure | Collision     | Collision        |
    And a Personal Auto policy
    When I start filing a claim
    And I select the "1st" covered vehicle
    And I finish filing the claim
    Then an exposure should be created on the claim
      | Coverage Type | Coverage Subtype |
      | Collision     | Collision        |

  @23480-2-GW
  Scenario: A business rule is created for automatically creating an Exposure
    Given I am a user with the "Business Rules Admin" role
    When I create a new exposure rule named "Test123"
      | Enabled | Policy Type   | Incident Type   |
      | Yes     | Personal Auto | VehicleIncident |
    And I promote the exposure rule "Test123" to staged
    Then the exposure rule "Test123" should be "Staged"
