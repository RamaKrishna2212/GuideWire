@personal_auto
Feature: Service Request

  As a customer service representative,
  I want to request services for new claims,
  so that services can be quoted and performed to recover the losses.

  Background:
    Given I am a user with the "Adjuster" role

  Scenario: A service request is created during FNOL for a new claim to "Quote and Perform Service" for "Auto Body"
    Given a Personal Auto policy
    When I start filing a claim
    And I select an involved vehicle from covered vehicles
    And I request a "Quote and Perform Service" for "Auto body"
    And I finish filing the claim
    Then a "Auto body" service should be requested on the claim
    And the request type should be "Quote and Perform Service"
