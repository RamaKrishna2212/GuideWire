@personal_auto
Feature: Create reserves and checks

  As an adjuster,
  I want to be able to create and edit reserves and checks.

  Background:
    Given I am a user with the "Adjuster" role
    And I have the "Adjuster" authority limit profile

  Scenario: Creating reserves upon exposure creation on a Personal Auto claim through the reserve business rule:
  IRR01120 - Auto Vehicle Damage Medium
    Given a Personal Auto claim
    # And reserve business rule: IRR01120 - Auto Vehicle Damage Medium is enabled
    When I create a comprehensive exposure on the claim
    Then the exposure should have the following remaining reserves:
      | Cost Type     | Cost Category      | Amount   |
      | Expense - A&O | Vehicle inspection | 500 USD  |
      | Claim Cost    | Auto body          | 2500 USD |

  Scenario Outline: Manually creating a reserve on an existing Personal Auto claim
    Given a Personal Auto claim
    And the claim has a bodily injury exposure
    When I create "<Reserve Amount>" available reserves for "<Cost Type>" and "<Cost Category>"
    Then the exposure should have the following remaining reserves:
      | Cost Type   | Cost Category   | Amount           |
      | <Cost Type> | <Cost Category> | <Reserve Amount> |

    Examples:
      | Cost Type     | Cost Category             | Reserve Amount |
      | Claim Cost    | Unspecified Cost Category | 500 USD        |
      | Expense - A&O | Vehicle inspection        | 300 USD        |

  Scenario Outline: Changing a reserve on an existing claim
    Given a Personal Auto claim
    And the claim has a bodily injury exposure
    And the exposure has "<Reserve Amount>" available reserves for "<Cost Type>" and "<Cost Category>"
    When I set "<New Reserve Amount>" available reserves for "<Cost Type>" and "<Cost Category>"
    Then the exposure should have the following remaining reserves:
      | Cost Type   | Cost Category   | Amount               |
      | <Cost Type> | <Cost Category> | <New Reserve Amount> |

    Examples:
      | Cost Type     | Cost Category             | Reserve Amount | New Reserve Amount |
      | Claim Cost    | Unspecified Cost Category | 500 USD        | 600 USD            |
      | Expense - A&O | Vehicle inspection        | 300 USD        | 200 USD            |

  Scenario Outline: Creating a payment when there are enough available reserves
    Given a Personal Auto claim
    And the claim has a bodily injury exposure
    And the exposure has "<Reserve Amount>" available reserves for "<Cost Type>" and "<Cost Category>"
    When I create a check with a "<Payment Amount>" "<Payment Type>" payment on the reserve line
    Then a "<Payment Amount>" "<Payment Type>" payment should exist on the reserve line
    Then the exposure should have the following remaining reserves:
      | Cost Type   | Cost Category   | Amount                     |
      | <Cost Type> | <Cost Category> | <Remaining Reserve Amount> |

    Examples:
      | Cost Type     | Cost Category             | Reserve Amount | Payment Amount | Remaining Reserve Amount | Payment Type |
      | Claim Cost    | Unspecified Cost Category | 500 USD        | 100 USD        | 400 USD                  | Partial      |
      | Expense - A&O | Vehicle inspection        | 300 USD        | 50 USD         | 0 USD                    | Final        |

  Scenario Outline: Editing a payment
    Given a Personal Auto claim
    And the claim has a bodily injury exposure
    And the exposure has "<Reserve Amount>" available reserves for "<Cost Type>" and "<Cost Category>"
    When I create a check with a "<Payment Amount>" "<Payment Type>" payment on the reserve line
    And I change the payment amount to "<New Payment Amount>"
    Then a "<New Payment Amount>" "<Payment Type>" payment should exist on the reserve line
    Then the exposure should have the following remaining reserves:
      | Cost Type   | Cost Category   | Amount                     |
      | <Cost Type> | <Cost Category> | <Remaining Reserve Amount> |

    Examples:
      | Cost Type     | Cost Category             | Reserve Amount | Payment Amount | New Payment Amount | Remaining Reserve Amount | Payment Type |
      | Claim Cost    | Unspecified Cost Category | 500 USD        | 100 USD        | 200 USD            | 300 USD                  | Partial      |
      | Expense - A&O | Vehicle inspection        | 300 USD        | 200 USD        | 50 USD             | 0 USD                    | Final        |

  Scenario: Creating a supplemental payment
    Given a Personal Auto claim
    And the claim has a "collision" exposure
    And the exposure has "500 USD" available reserves for "Claim Cost" and "Unspecified Cost Category"
    And the exposure has a check with a "500 USD" "Partial" payment on the reserve line
    And the exposure is closed
    And the claim is closed
    When I create a check with a "800 USD" "Supplement" payment on the reserve line
    Then a "800 USD" "Supplement" payment should exist on the reserve line

  Scenario: Creating a payment for an amount more than the available reserve
    Given a Personal Auto claim
    And the claim has a "collision" exposure
    And I choose the insured to be the claimant for the vehicle exposure
    And the exposure has "400 USD" available reserves for "Claim Cost" and "Auto Body"
    When I start creating a check
    And I create a payment on the exposure
      | Cost Type  | Cost Category             | Reserving Currency | Payment Type | Eroding |
      | Claim Cost | Unspecified Cost Category | USD                | Final        | Yes     |
    And I create these line items
      | Category              | Amount |
      | Mileage reimbursement | 300    |
      | Other                 | 200    |
    And I finish creating a check

    Given a Personal Auto claim
    And the claim has a "collision" exposure
    And I choose the insured to be the claimant for the vehicle exposure
    And the exposure has "400 USD" available reserves for "Claim Cost" and "Auto Body"
    When I start creating a check
    # Default to Insured if not set
    # And the "Insured" is the primary payee
    # I am paying via check / EFT
    And I create a payment on the exposure
      | Cost Type  | Cost Category             | Reserving Currency | Payment Type | Eroding |
      | Claim Cost | Unspecified Cost Category | USD                | Partial      | Yes     |
    And I create these line items
      | Category              | Amount |
      | Mileage reimbursement | 300    |
    Then I cannot finish because "This payment cannot be added because the sum of its line items' amounts exceeds the available reserves for its ReserveLine."

  # This scenario depends on AllowNoPriorPaymentSupplement being false
  Scenario: Payments on closed claims
    Given a Personal Auto claim
    And the claim has a "collision" exposure
    And I choose the insured to be the claimant for the vehicle exposure
    And all exposures are closed
    And the claim is closed
    And the claim has no prior payments or checks
    Then payment options are not available on the closed claim

  Scenario: Supplemental payment on closed claims
    Given a Personal Auto claim
    And the claim has a "collision" exposure
    And I choose the insured to be the claimant for the vehicle exposure
    And the exposure has "500 USD" available reserves for "Claim Cost" and "Unspecified Cost Category"
    And the exposure has a check with a "500 USD" "Partial" payment on the reserve line
    And all exposures are closed
    And the claim is closed
    Then payment options are not available on the closed claim
