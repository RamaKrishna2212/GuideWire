@personal_auto
Feature: Parties Involved

  As an adjuster,
  I want to add contacts for existing claims.

  Background:
    Given I am a user with the "Adjuster" role

  Scenario: Add a new contact on an existing claim
    Given a Personal Auto claim
    And the claim has a "collision" exposure
    And I choose the insured to be the claimant for the vehicle exposure
    When I add an "Auto Repair Shop" contact with "Vendor" role to the existing exposure
      | Name         | Express Auto      |
      | Address 1    | 8982 Merrydale Dr |
      | City         | San Francisco     |
      | ZIP Code     | 94104             |
      | State        | California        |
      | Country      | United States     |
      | Address Type | Business          |
      | Work         | 2092348728        |
      | Tax ID (EIN) | 77-7752421        |
    Then the contact is a Parties Involved contact
      | Name         | Express Auto      |
      | Address      | 8982 Merrydale Dr |
      | City         | San Francisco     |
      | ZIP Code     | 94104             |
      | State        | CA                |
      | Address Type | Business          |
      | Work         | 209-234-8728      |
      | Roles        | Vendor            |

  Scenario: Add an existing contact to the claim
    Given a Personal Auto claim
    And the claim has a "Medical Payments" exposure
    And I choose the insured to be the claimant for the vehicle exposure
    And a "Medical Care Organization" contact exists in the address book
      | Name      | Health South         |
      | City      | San Francisco        |
    When I add that contact as a party on the claim with "Hospital - Medical Center" role to the existing exposure
    Then the contact is a Parties Involved contact
      | Name      | Health South                             |
      | Address   | 9032 Market Str                          |
      | City      | San Francisco                            |
      | ZIP Code  | 94104                                    |
      | State     | CA                                       |
      | Location  | 9032 Market Str, San Francisco, CA 94104 |
