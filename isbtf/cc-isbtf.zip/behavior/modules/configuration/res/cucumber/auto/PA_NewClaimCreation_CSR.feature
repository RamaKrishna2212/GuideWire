@personal_auto
Feature: New Claim Creation

  As a customer service representative,
  I want to file claims against verified policies, and issue checks while filing claims through Auto First and Final Wizard.

  Background:
    Given I am a user with the "Customer Service Representative" role
    And I have the "Adjuster" authority limit profile

  Scenario Outline: Filing a new Personal Auto claim with a loss cause
    Given a Personal Auto policy
    When I start filing a claim
    And I set claim loss cause to "<Loss Cause>"
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And the claim loss cause should be "<Loss Cause>"

    Examples:
      | Loss Cause                   |
      | Animal                       |
      | Collision while turning left |
      | Glass breakage               |

  Scenario: Filing a new Personal Auto claim for collision with motor vehicle to an insured's vehicle
    Given a Personal Auto policy
    When I start filing a claim
    And I select the "1st" covered vehicle
    And I set claim loss cause to "Collision with motor vehicle"
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And an incident for the selected vehicle should be created on the claim
    And a "Collision" exposure should be created on the claim

  Scenario: Filing a new Personal Auto claim through Auto First and Final Wizard
    Given a Personal Auto policy
    When I start filing a claim in Auto First and Final Wizard
    And I add an autobody repair shop "Advanced Auto Repair Center"
    And I create a "500 USD" check to "Advanced Auto Repair Center"
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And a "500 USD" check to "Advanced Auto Repair Center" should exist on the claim