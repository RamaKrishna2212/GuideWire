@personal_auto @RSS-04-Salvage
Feature: Salvage

  As a manager,
  I want the system to populate the vehicle recovery date when the salvage vehicle activity is completed,
  So that we can track completed vehicle salvages.

  Background:
    Given I am a user with the "Manager" role

  @23530-GW
  Scenario: A vehicle recovery date is when I complete the salvage
    Given a Personal Auto claim
    And the claim has a "collision" exposure
    And the vehicle incident is indicated as a total loss
    When I complete the "Salvage Vehicle" activity
    Then the vehicle recovery date should be today