@personal_auto @PA-DetermineHandlingStrategy-Assignment
Feature: Assignment

  As an adjuster,
  I want to reassign claims and exposures manually and automated using assignment rules.

  @23550-GW
  Scenario: Reassigning an exposure through automated assignment on a Personal Auto claim
    Given I am a user with the "Adjuster" role
    And a Personal Auto claim
    And the claim is assigned to group "Auto1 - TeamB" and user "Pam Vance"
    And the claim has a "collision" exposure
    And the exposure is assigned to group "Cleveland Liability Adjusters" and user "Ernie Pasquale"
    When I reassign the exposure through automated assignment
    Then the exposure should be assigned to the claim owner

  @23550-GW
  Scenario: Manually reassigning an exposure on a Personal Auto claim
    Given I am a user with the "Adjuster" role
    And a Personal Auto claim
    And the claim has a "collision" exposure
    And the exposure is assigned to group "Cleveland Liability Adjusters" and user "Ernie Pasquale"
    When I manually reassign the exposure to group "Auto1 - TeamA" and user "Betty Baker"
    Then the exposure should be assigned to group "Auto1 - TeamA"
    And the exposure should be assigned to user "Betty Baker"

  @23550-GW
  Scenario: Manually reassigning an activity on a Personal Auto claim
    Given I am a user with the "Adjuster" role
    And a Personal Auto claim
    And the claim has an activity
    And the activity is assigned to group "Cleveland Liability Adjusters" and user "Ernie Pasquale"
    When I manually reassign the activity to group "Auto1 - TeamB" and user "Heidi Johnson"
    Then the activity should be assigned to group "Auto1 - TeamB"
    And the activity should be assigned to user "Heidi Johnson"

  @23550-GW-I
  Scenario: Assigning a claim and exposure through automated assignment on new Personal Auto claim
    Given I am a user with the "Customer Service Representative" role
    And a Personal Auto policy
    # And exposure business rule: EC01000 - Personal Auto Collision is enabled
    # And gosu rules to automatically assign the claim: GCAA00010 - If the claim loss type is Auto, this rule uses the loss type and claim segment to get the top two matching group type choices for assigning this claim.
    # And gosu rules to automatically assign the exposure: GEA03000 - If the exposure is still not assigned, this rule assigns the exposure to the assigned owner and group for the claim.
    When I start filing a claim
    And I select an involved vehicle from covered vehicles
    And I set loss location to an address in state "California"
    And I set claim loss cause to "Collision with bicycle"
    And I assign the claim individually through automated assignment
    And I assign the "Collision" exposure through automated assignment
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And the claim should be assigned to a user in "Auto1 - TeamB" group
    And the exposure should be assigned to the claim owner

  @23550-GW
  Scenario: Assigning a claim manually and an exposure through automated assignment on new Personal Auto claim
    Given I am a user with the "Customer Service Representative" role
    And a Personal Auto policy
    When I start filing a claim
    And I select an involved vehicle from covered vehicles
    And I set loss location to an address in state "California"
    And I set claim loss cause to "Collision with bicycle"
    And I manually assign the claim individually to group "Auto1 - TeamA" and user "Betty Baker"
    And I assign the "Collision" exposure through automated assignment
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And the claim should be assigned to group "Auto1 - TeamA"
    And the claim should be assigned to user "Betty Baker"
    And the exposure should be assigned to the claim owner

  @23550-GW
  Scenario: Assigning a claim through automated assignment and manually assigning an exposure on new Personal Auto claim
    Given I am a user with the "Customer Service Representative" role
    And a Personal Auto policy
    When I start filing a claim
    And I select an involved vehicle from covered vehicles
    And I set loss location to an address in state "California"
    And I set claim loss cause to "Collision with bicycle"
    And I assign the claim individually through automated assignment
    And I manually assign the "Collision" exposure to group "Auto1 - TeamA" and user "Betty Baker"
    And I finish filing the claim
    Then a "Personal Auto" claim should be created
    And the claim should be assigned to a user in "Auto1 - TeamB" group
    And the exposure should be assigned to group "Auto1 - TeamA"
    And the exposure should be assigned to user "Betty Baker"