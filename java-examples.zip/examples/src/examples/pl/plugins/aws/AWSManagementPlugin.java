package examples.pl.plugins.aws;

import gw.plugin.InitializablePlugin;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatch.CloudWatchClient;
import software.amazon.awssdk.services.cloudwatch.model.Dimension;
import software.amazon.awssdk.services.cloudwatch.model.MetricDatum;
import software.amazon.awssdk.services.cloudwatch.model.PutMetricDataRequest;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import gw.pl.logging.LoggerCategory;
import gw.plugin.PluginParameter;
import gw.plugin.management.GWMBean;
import gw.plugin.management.ManagementAuthorizationCallbackHandler;
import gw.plugin.management.ManagementPlugin;
import gw.plugin.management.Notification;
import gw.util.Pair;

import javax.annotation.Nonnull;
import java.net.URL;
import java.net.URLConnection;
import java.time.Instant;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

/**
 * Example management plugin for publishing application metrics to AWS Cloudwatch as custom metrics. The plugin
 * periodically publishes specified attributes of management beans to Cloudwatch.<br></br>
 * Configuration parameters:
 * <ul>
 * <li>{@code secretKey}: AWS credentials secret key</li>
 * <li>{@code accessKey}: AWS credentials access key</li>
 * <li>{@code region}: AWS Cloudwatch region to which custom metrics will be published. If not specified the region of the instance is used.</li>
 * <li>{@code namespace}: Namespace under which the metrics are published; Default is GW-EXAMPLE.</li>
 * <li>{@code initialDelay}: number of seconds to wait before starting to publish metrics to Cloudwatch. Default is 5seconds.</li>
 * <li>{@code period}: frequency, in seconds, of publishing metrics to Cloudwatch</li>
 * <li> Metrics to be published are specified as:
 * <pre>
 *   {@code &lt;param name=&quot;metricMETRIC_NAME&quot; value=&quot;BEAN_NAME&nbsp;ATTRIBUTE&quot;/&gt;}
 * </pre>
 * which will result in the attribute named {@code ATTRIBUTE} of the bean named {@code BEAN_NAME} to be published to
 * Cloudwatch as the metric named {@code METRIC_NAME}. For example, to publish the {@code NumberOfUserSessions} attribute
 * of the managment bean {@code com.guidewire.pl.system.monitor:type=general} as a Cloudwatch metric named UserSessionCount add
 * <pre>
 *   {@code &lt;param name=&quot;metricUserSessionCount&quot; value=&quot;com.guidewire.pl.system.monitor:type=general NumberOfUserSessions&quot;&gt;}
 * </pre>
 * </li>
 * </ul>
 */
@PluginParameter(name="accessKey", type= PluginParameter.Type.String)
@PluginParameter(name="secretKey", type= PluginParameter.Type.String)
@PluginParameter(name="region", type= PluginParameter.Type.String)
@PluginParameter(name="namespace", type= PluginParameter.Type.String)
@PluginParameter(name="initialDelay", type= PluginParameter.Type.Integer)
@PluginParameter(name="period", type= PluginParameter.Type.Integer)
@PluginParameter(name="metric.*", helpText = "This will publish any parameter that starts with \"metric\" as mbean for example metricXyz will be publish Xyz as an mbeans" )
public class AWSManagementPlugin implements ManagementPlugin, InitializablePlugin {
  private Map<?,?> _params;
  // private ManagementAuthorizationCallbackHandler _callbackHandler;

  private String _namespace;
  private Dimension _instanceIdDim;
  private CloudWatchClient _cloudwatch;

  private ConcurrentHashMap<String, GWMBean> _beanNameToBeanMap = new ConcurrentHashMap<>();
  private Map<String, List<Pair<String, String>>> _beanNameToMetrics = new HashMap<>();

  private ScheduledExecutorService _executor;

  @Override
  public void setParameters(Map params) {
    _params = params;
    LoggerCategory.PLUGIN.info("AWSManagementPlugin Initialized.");
  }

  @Override
  public void start() {
    LoggerCategory.PLUGIN.info("AWSManagementPlugin Starting");

    String region = (String) _params.get("region");
    if (region == null || region.isBlank()) {
      region = getInstanceRegion();
    }

    final AwsCredentials credentials =
            AwsBasicCredentials.create((String) _params.get("accessKey"), (String) _params.get("secretKey"));

    _cloudwatch = CloudWatchClient.builder()
            .credentialsProvider(() -> credentials)
            .region(Region.of(region))
            .build();

    String namespace = (String) _params.get("namespace");
    _namespace = namespace == null ? "GW-EXAMPLE" : namespace;
    _instanceIdDim = Dimension.builder()
            .name("InstanceId")
            .value(getInstanceId())
            .build();

    _beanNameToMetrics = setupMetricsToPublish();

    long initialDelay = 5;
    if (_params.get("initialDelay") != null) {
      try {
        initialDelay = Long.parseLong((String) _params.get("initialDelay"));
      } catch (NumberFormatException ignore) {
      }
    }

    long period = 60;
    if (_params.get("period") != null) {
      try {
        period = Long.parseLong((String) _params.get("period"));
      } catch (NumberFormatException ignore) {
      }
    }

    _executor = Executors.newSingleThreadScheduledExecutor(new DaemonThreadFactory());
    _executor.scheduleAtFixedRate(this::publishMetrics, initialDelay, period, TimeUnit.SECONDS);
  }

  @Override
  public void stop() {
    _executor.shutdown();
  }

  @Override
  public void registerBean(GWMBean bean) {
    _beanNameToBeanMap.put(bean.getBeanName(), bean);
    LoggerCategory.PLUGIN.info("AWSManagementPlugin: Registered bean: {}", bean.getBeanName());
  }

  @Override
  public void unregisterBean(GWMBean bean) {
    _beanNameToBeanMap.remove(bean.getBeanName());
    LoggerCategory.PLUGIN.info("AWSManagementPlugin: Unregistered bean: {}", bean.getBeanName());
  }

  public void unregisterBeanByNamePrefix(String prefix) {
    for (String beanName : _beanNameToBeanMap.keySet()) {
      if (beanName.startsWith(prefix)) {
        unregisterBean(_beanNameToBeanMap.get(beanName));
      }
    }
  }

  @Override
  public void sendNotification(Notification notification) {
  }

  @Override
  public void setAuthorizationCallbackHandler(ManagementAuthorizationCallbackHandler handler) {
    // _callbackHandler = handler;
  }

  private Map<String, List<Pair<String, String>>> setupMetricsToPublish() {
    Map<String, List<Pair<String, String>>> beanNameToMetrics = new HashMap<>();
    for (Object paramNameObject : _params.keySet()) {
      String paramName = paramNameObject.toString();
      if (paramName.startsWith("metric")) {
        String metricName = paramName.substring(6);
        String paramValue = (String) _params.get(paramName);
        List<String> splits = Lists.newArrayList(Splitter.on(' ').trimResults().split(paramValue));

        if (splits.size() == 2) {
          String beanName = splits.get(0);
          String attribute = splits.get(1);
          Pair<String, String> metricAndAttribute = new Pair<>(metricName, attribute);
          List<Pair<String, String>> metricsFromBean = beanNameToMetrics.get(beanName);
          if (metricsFromBean == null) {
            metricsFromBean = Lists.newArrayList();
            metricsFromBean.add(metricAndAttribute);
            beanNameToMetrics.put(beanName, metricsFromBean);
          } else {
            metricsFromBean.add(metricAndAttribute);
          }
          LoggerCategory.PLUGIN.info("AWSManagementPlugin: Added Metric to Publish. Metric Name: {} Bean: {} Attribute: {}",
                  metricName, beanName, attribute);
        } else {
          LoggerCategory.PLUGIN.warn("AWSManagementPlugin: Ignored metric {} = {} - name, bean, and attr must all be specified.",
                  paramName, paramValue);
        }
      }
    }

    return beanNameToMetrics;
  }

  private void publishMetrics() {
    List<MetricDatum> metricData = new LinkedList<>();
    for (Map.Entry<String, List<Pair<String, String>>> beanEntry : _beanNameToMetrics.entrySet()) {
      String beanName = beanEntry.getKey();
      GWMBean bean = _beanNameToBeanMap.get(beanName);
      if (bean != null) {
        List<Pair<String, String>> metricsFromBean = beanEntry.getValue();

        for (Pair<String, String> metricAndAttribute : metricsFromBean) {
          String metricName = metricAndAttribute.getFirst();
          String attribute = metricAndAttribute.getSecond();
          try {
            Object attributeValue = bean.getAttribute(attribute);
            if (attributeValue instanceof Number) {
              Double metricValue = ((Number) attributeValue).doubleValue();
              metricData.add(MetricDatum.builder()
                      .dimensions(_instanceIdDim)
                      .metricName(metricName)
                      .timestamp(Instant.now())
                      .unit("Count")
                      .value(metricValue)
                      .build());
              LoggerCategory.PLUGIN.debug("AWSManagementPlugin: Added datum to publish. {} = {}", metricName, metricValue);
            } else {
              LoggerCategory.PLUGIN.warn("AWSManagementPlugin: Cannot publish metric {} (Bean: {} Attribute {}) as attribute value is not a number",
                      metricName, beanName, attribute);
            }
          } catch (Throwable th) {
            LoggerCategory.PLUGIN.warn("AWSManagementPlugin: Cannot get attribute {} of bean {} - Exception {}", attribute, beanName, th.getMessage());
          }
        }
      } else {
        LoggerCategory.PLUGIN.warn("AWSManagementPlugin: Cannot find bean with name = {}", beanName);
      }
    }

    if (metricData.isEmpty()) {
      LoggerCategory.PLUGIN.warn("AWSManagementPlugin: No metrics available to publish.");
    } else {
      try {
        _cloudwatch.putMetricData(PutMetricDataRequest.builder()
                .namespace(_namespace)
                .metricData(metricData)
                .build());
        LoggerCategory.PLUGIN.info("AWSManagementPlugin: Published {} metrics.", metricData.size());
      } catch (Throwable th) {
        LoggerCategory.PLUGIN.warn("AWSManagementPlugin: Error publishing metrics", th);
      }
    }
  }

  // http://docs.aws.amazon.com/AWSEC2/latest/UserGuide/AESDG-chapter-instancedata.html
  private String getInstanceId() {
    String id = "id-UNKNOWN";
    Scanner s = null;
    try {
      URL url = new URL("http://instance-data/latest/meta-data/instance-id");
      URLConnection conn = url.openConnection();
      s = new Scanner(conn.getInputStream());
      if (s.hasNext()) {
        id = s.next();
      }
    } catch (Throwable th) {
      LoggerCategory.PLUGIN.error("Error getting InstanceId: ", th);
    } finally {
      if (s != null) {
        s.close();
      }
    }
    return id;
  }

  // http://docs.aws.amazon.com/AWSEC2/latest/UserGuide/AESDG-chapter-instancedata.html
  public String getInstanceRegion() {
    String region = Region.US_WEST_1.id();
    Scanner s = null;
    try {
      URL url = new URL("http://instance-data/latest/meta-data/placement/availability-zone");
      URLConnection conn = url.openConnection();
      s = new Scanner(conn.getInputStream());
      if (s.hasNext()) {
        region = s.next();
      }
    } catch (Throwable th) {
      LoggerCategory.PLUGIN.error("Error getting instance region: ", th);
    } finally {
      if (s != null) {
        s.close();
      }
    }
    return region;
  }

  private static class DaemonThreadFactory implements ThreadFactory {
    private final ThreadFactory _factory;

    public DaemonThreadFactory() {
      this(Executors.defaultThreadFactory());
    }

    public DaemonThreadFactory(@Nonnull ThreadFactory factory) {
      _factory = factory;
    }

    @Override
    public Thread newThread(@Nonnull Runnable runnable) {
      Thread thread = _factory.newThread(runnable);
      thread.setDaemon(true);
      thread.setName("AWSManagementPlugin Publisher");
      return thread;
    }
  }
}
